import React from 'react';
import { 
  Rocket, 
  CheckCircle, 
  Star, 
  Store, 
  Mail, 
  QrCode, 
  BarChart, 
  FileText,
  Video,
  MessageCircle,
  ArrowRight,
  Clock,
  Image,
  RefreshCw,
  Link,
  MessageSquare
} from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-16 text-center">
        <div className="flex items-center justify-center mb-6">
          <Rocket className="w-12 h-12 text-blue-600" />
          <h1 className="text-4xl font-bold text-gray-900 ml-3">GoogleBoost</h1>
        </div>
        <p className="text-xl text-gray-600 mb-8">
          Référencement et avis Google 100% gratuit pour votre restaurant
        </p>
        <div className="bg-blue-600 text-white py-3 px-6 rounded-full inline-block hover:bg-blue-700 transition cursor-pointer">
          Commencer Gratuitement
        </div>
      </header>

      {/* Why Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Pourquoi GoogleBoost ?</h2>
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="bg-blue-50 p-6 rounded-lg">
              <Store className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Visibilité Gratuite</h3>
              <p className="text-gray-600">
                Apparaissez sur Google sans dépenser en publicité grâce à l'optimisation de Google My Business
              </p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg">
              <Star className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Optimisation SEO</h3>
              <p className="text-gray-600">
                Optimisez votre site avec des plugins gratuits comme Rank Math ou Yoast SEO
              </p>
            </div>
            <div className="bg-blue-50 p-6 rounded-lg">
              <MessageSquare className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Gestion des Avis</h3>
              <p className="text-gray-600">
                Collectez et affichez facilement les avis positifs de vos clients
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Comment ça marche ?</h2>
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-white p-8 rounded-lg shadow-lg mb-8">
              <h3 className="text-xl font-semibold mb-4">1. Google My Business</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <Store className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Création de votre fiche professionnelle</p>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <Clock className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Configuration des horaires et informations</p>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <Image className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Ajout de photos de haute qualité</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg mb-8">
              <h3 className="text-xl font-semibold mb-4">2. Optimisation WordPress</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Installation des plugins SEO gratuits</p>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <FileText className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Publication d'articles optimisés</p>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <Link className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Optimisation des liens internes et externes</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg shadow-lg mb-8">
              <h3 className="text-xl font-semibold mb-4">3. Gestion des Avis</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <Mail className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Système de demande d'avis par email</p>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <QrCode className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">QR code pour les avis clients</p>
                </div>
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-4">
                    <MessageCircle className="w-6 h-6" />
                  </div>
                  <p className="text-gray-700">Gestion et réponse aux avis</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-gray-50 py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Fonctionnalités Supplémentaires</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <BarChart className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Tableau de Bord</h3>
              <p className="text-gray-600">Suivez vos performances en temps réel</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <FileText className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Modèles d'Emails</h3>
              <p className="text-gray-600">Templates prêts à l'emploi</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <Video className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Formation en Ligne</h3>
              <p className="text-gray-600">Tutoriels vidéo et guides PDF</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <MessageCircle className="w-8 h-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Support Client</h3>
              <p className="text-gray-600">Assistance par email et chat</p>
            </div>
          </div>
        </div>
      </section>

      {/* Plan Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Notre Plan d'Action</h2>
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex items-start">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-6 mt-1">
                <Rocket className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Phase 1 : Lancement</h3>
                <p className="text-gray-600">Documentation complète, site web professionnel et campagne de communication ciblée</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-6 mt-1">
                <Star className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Phase 2 : Premiers Clients</h3>
                <p className="text-gray-600">Accompagnement personnalisé et création d'études de cas</p>
              </div>
            </div>
            <div className="flex items-start">
              <div className="bg-blue-100 p-3 rounded-full text-blue-600 mr-6 mt-1">
                <RefreshCw className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-2">Phase 3 : Amélioration Continue</h3>
                <p className="text-gray-600">Analyse des retours et ajout de nouvelles fonctionnalités</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Prêt à booster votre présence sur Google ?</h2>
          <p className="text-xl mb-8">Commencez gratuitement dès aujourd'hui</p>
          <button className="bg-white text-blue-600 py-3 px-8 rounded-full font-semibold hover:bg-blue-50 transition flex items-center mx-auto">
            Démarrer Maintenant
            <ArrowRight className="w-5 h-5 ml-2" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 py-8">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© 2024 GoogleBoost - Tous droits réservés</p>
        </div>
      </footer>
    </div>
  );
}

export default App;